Clazz.declarePackage ("J.rendersurface");
Clazz.load (["J.rendersurface.PmeshRenderer"], "J.rendersurface.Plot3DRenderer", null, function () {
c$ = Clazz.declareType (J.rendersurface, "Plot3DRenderer", J.rendersurface.PmeshRenderer);
});
